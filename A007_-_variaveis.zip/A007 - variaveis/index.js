//Oi, bom dia pessoal. Boa aula a todos!

/* Receita de Bolo
2 xícara de farinha
1 xícara de açucar */

//Primeira aula de variaveis

console.log("Bom dia turma Ammal!")

//prompt("qual é o seu nome?")


/*
const nome = "Murilo de Sousa"
console.log(nome)

let idade = 27
idade = 28
console.log(idade)

idade = 21.5
console.log("meu nome é", nome, 'minha idade é', idade)

//variavel booleana - true ou false
let temPet = true
console.log(temPet)

const nomePet = null
console.log("o nome do pet é:", nomePet)

//Verificar Tipos
console.log("o tipo do nome é:", typeof(nome))
console.log("o tipo da idade é:", typeof(idade))
console.log("o tipo do temPet é: ", typeof temPet)
console.log(typeof(nomePet))
*/


const nomePrompt = prompt("Qual é o seu nome?")
console.log(nomePrompt)

let idade = prompt("Qual é a sua idade") // "25" -> 25
console.log(idade)

console.log(typeof(nomePrompt))
console.log(typeof(idade)) // string

//Conversão de tipo string -> number
idade = Number(idade)
console.log(typeof(idade)) //number
console.log(idade)


//Conversão de tipo Number -> String
let numero = 10
console.log(typeof(numero)) //number

numero = String(numero) //converti tipo number para tipo String
console.log(typeof(numero)) //string